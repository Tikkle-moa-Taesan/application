package com.ssafy.TmT.dto.member;

public class MemberPreviewDataDTO {

}
