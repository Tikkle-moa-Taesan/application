package com.ssafy.TmT.dto.account;

public enum AccountType {

	free, savings;
}
