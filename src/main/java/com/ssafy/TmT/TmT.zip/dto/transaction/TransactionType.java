package com.ssafy.TmT.dto.transaction;

public enum TransactionType {
	expense,income;
}
