//package com.ssafy.TmT.dto.member;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import com.fasterxml.jackson.annotation.JsonProperty;
//import com.ssafy.TmT.dto.account.AccountDTO;
//import com.ssafy.TmT.dto.budget.BudgetDTO;
//import com.ssafy.TmT.dto.transaction.BudgetTransactionDTO;
//
//import lombok.AllArgsConstructor;
//import lombok.Getter;
//import lombok.NoArgsConstructor;
//import lombok.Setter;
//
//@Getter
//@Setter
//@NoArgsConstructor
//@AllArgsConstructor
//public class MemberTotalDataDTO {
//	@JsonProperty("accounts")
//    private List<AccountDTO> accounts = new ArrayList<>(); // 빈 리스트로 초기화
//	@JsonProperty("budgets")
//    private List<BudgetDTO> budgets = new ArrayList<>();;
//	@JsonProperty("transactions")
//    private List<BudgetTransactionDTO> transactions = new ArrayList<>();; // 빈 리스트로 초기화
//}
//	