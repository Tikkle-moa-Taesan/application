package com.ssafy.TmT.dto.budget;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CreateBudgetRequest {

	private Long monthBudget;
}
